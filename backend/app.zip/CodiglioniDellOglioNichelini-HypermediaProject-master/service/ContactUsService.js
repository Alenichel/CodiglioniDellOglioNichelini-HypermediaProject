'use strict';


/**
 * Send a message via a form
 *
 * name String 
 * email String 
 * subject String 
 * message String 
 * no response value expected for this operation
 **/
exports.contactPOST = function(name,email,subject,message) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

